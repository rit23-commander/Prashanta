import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, ScriptException {

        ScriptEngineManager manager = new ScriptEngineManager();
       ScriptEngine js = manager.getEngineByName("nashorn");
       js.eval(new FileReader("/home/suprem_kai/IdeaProjects/Internet Window/src/Html/login.html"));
        String var = js.get("password").toString();

        System.out.println("Hello world!"+var);
    }
}