package com.Internet.window.fram;

import com.Internet.window.fram.Top.TopBar;
import com.Internet.window.fram.Web_load.jfxpanel;
import javafx.embed.swing.JFXPanel;

import javax.swing.*;
import java.awt.*;

public class Frame extends JFrame {

    public String title = "" ;
    public Frame() {
        setVisible(true);
        setSize(500, 500);
        setLayout(new BorderLayout());
        new JFXPanel();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Spider Web");
        item();
    }
    private void item(){
       add(new TopBar() , BorderLayout.NORTH);
       add(new jfxpanel() , BorderLayout.CENTER);
    }
    public static void main(String [] args) {
        new Frame();

    }
}
