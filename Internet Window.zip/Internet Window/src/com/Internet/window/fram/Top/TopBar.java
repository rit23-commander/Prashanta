package com.Internet.window.fram.Top;

import com.Internet.window.fram.Web_load.jfxpanel;
import com.Internet.window.fram.allAccess.Action;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TopBar extends JToolBar {

    private JLabel back, fw, refresh, setting;
    private ImageIcon bc, fr, ref, seti;
    private JTextField url_display;

    public TopBar() {


        bc = new ImageIcon("/home/suprem_kai/IdeaProjects/Internet Window/src/icon/back.png");
        fr = new ImageIcon("/home/suprem_kai/IdeaProjects/Internet Window/src/icon/for.png");
        ref = new ImageIcon("/home/suprem_kai/IdeaProjects/Internet Window/src/icon/re.png");

        back = new JLabel(bc);
        back.setToolTipText("back");
        fw = new JLabel(fr);
        refresh = new JLabel(ref);
        refresh.setToolTipText("refresh");
        // setting = new JLabel(seti);

        LineBorder lineBorder = new LineBorder(Color.MAGENTA, 2, true);
        url_display = new JTextField();
        url_display.setBorder(lineBorder);
        url_display.setColumns(5);
        url_display.setFont(new Font(Font.SERIF, Font.PLAIN, 12));

        setFloatable(false);

        add(back);
        add(new JLabel("     "));
        add(fw);
        add(new JLabel("     "));
        add(refresh);
        add(new JLabel("         "));
        add(url_display);
        add(new JLabel("     "));
        new jfxpanel().access(url_display);

        back.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new Action().web_Action("back");
            }
        });
        fw.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new Action().web_Action("for");
            }
        });
        refresh.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                new Action().web_Action("ref");
            }
        });

        url_display.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == 10) {
                    new Action().load(url_display.getText());
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

    }

}
