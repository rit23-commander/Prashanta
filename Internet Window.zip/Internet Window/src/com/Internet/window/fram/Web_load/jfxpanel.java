package com.Internet.window.fram.Web_load;

import com.Internet.window.fram.Frame;
import com.Internet.window.fram.allAccess.Action;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.JFXPanel;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebEvent;
import javafx.scene.web.WebView;
import jdk.javadoc.internal.doclets.formats.html.Navigation;

import javax.swing.*;

public class jfxpanel extends JFXPanel {

    private static JTextField txt ;
    public void access(JTextField sl) {

        txt = sl ;

    }

   public  jfxpanel() {
       Platform.runLater(new Runnable() {
           @Override
           public void run() {
               WebView web = new WebView();
               WebEngine eg = web.getEngine();

               new Action().web(eg);
               eg.setOnAlert(new EventHandler<WebEvent<String>>() {
                   @Override
                   public void handle(WebEvent<String> stringWebEvent) {

                   }
               });
               eg.load("file:///home/suprem_kai/IdeaProjects/Internet%20Window/src/Html/index.html");
               eg.setJavaScriptEnabled(true);
               setScene(new Scene(web));

eg.locationProperty().addListener(new ChangeListener<String>() {
    @Override
    public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                txt.setText(t1);
            }
        });
    }
});
           }
       });
    }


}
