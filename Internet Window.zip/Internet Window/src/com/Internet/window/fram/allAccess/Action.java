package com.Internet.window.fram.allAccess;

import com.Internet.window.fram.Frame;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebHistory;

import javax.swing.*;
import javax.swing.event.ChangeEvent;

import javafx.beans.value.ChangeListener;


public class Action {



    private static WebEngine eg  ;
    private static JTextField url_display ;


    public void web(WebEngine hs) {
        eg = hs ;
    }

    public static void web_Action(String com) {
        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                WebHistory history = eg.getHistory();
                ObservableList<WebHistory.Entry> enter = history.getEntries();
                switch (com) {
                    case "ref":
                    eg.reload();
                    break ;

                    case "back" :

                        history.go(-1);
                        break ;
                    case "for":
                        history.go(1);
                        break;


                }

            }
        });
    }

    public void load(String load) {

        Platform.runLater(new Runnable() {
            @Override
            public void run() {
                if(load.contains("http") || load.contains("https")) {
                    eg.load(load);
                }
                else {
                    String s = "https://www.google.com/search?q=" ;

                    eg.load(s+load.trim());
                }
            }
        });

    }



}
